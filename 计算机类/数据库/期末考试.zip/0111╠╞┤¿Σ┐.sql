--------------------------------------------------------------
------------------------(1)创建表格----------------------------
--------------------------------------------------------------
CREATE TABLE department(
    dep_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT COMMENT '科室id',
    dep_name VARCHAR(30) NOT NULL DEFAULT '' COMMENT '科室名字',
    dep_addr varchar(50) NOT NULL DEFAULT '' COMMENT '科室地址',
    dep_phone char(8) NOT NULL DEFAULT '00000000' COMMENT '科室电话'
)ENGINE=INNODB DEFAULT CHARSET=utf8 COMMENT '科室';
CREATE TABLE doctor(
    doc_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT COMMENT '医生id',
    doc_idc SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT '医生工作证号',
    doc_name VARCHAR(20) NOT NULL DEFAULT '' COMMENT '医生名字',
    doc_sta VARCHAR(10) NOT NULL DEFAULT '' COMMENT '医生职称',
    doc_age TINYINT NOT NULL DEFAULT 0 COMMENT '医生年龄',
    -- 外键
    dep_id INT UNSIGNED NOT NULL COMMENT '科室id'
)ENGINE=INNODB DEFAULT CHARSET=utf8 COMMENT '医生';
-- 外键索引
CREATE INDEX index_doc ON doctor(dep_id);
CREATE TABLE patient(
    pat_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT COMMENT '病人id',
    pat_idc INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '病历号',
    pat_name VARCHAR(30) NOT NULL DEFAULT '' COMMENT '患者姓名',
    pat_sex ENUM('男','女') COMMENT '患者性别',
    -- 外键
    doc_id INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '医生id',
    wad_id INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '病房id'
)ENGINE=INNODB DEFAULT CHARSET=utf8 COMMENT '患者';
-- 外键索引
CREATE INDEX index_pat ON patient(wad_id,doc_id);
CREATE TABLE ward(
    wad_id INT UNSIGNED PRIMARY KEY AUTO_INCREMENT COMMENT '病房id',
    wad_idc INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '病房号',
    wad_addr VARCHAR(30) NOT NULL DEFAULT '' COMMENT '地址',
    -- 外键
    dep_id INT UNSIGNED NOT NULL DEFAULT 0 COMMENT '科室id'
)ENGINE=INNODB DEFAULT CHARSET=utf8 COMMENT '病房';
-- 外键索引
CREATE INDEX index_ward ON ward(dep_id);
--------------------------------------------------------------
------------------------(2)创建用户----------------------------
--------------------------------------------------------------
CREATE USER exam1@'localhost' identified by '111';
GRANT SELECT ON exam.* TO 'exam1'@'localhost'; 
CREATE USER exam2@'localhost' identified by '000';
GRANT CREATE,INSERT,UPDATE,DELETE ON exam.* TO 'exam2'@'localhost' with GRANT OPTION;
--------------------------------------------------------------
------------------------(3)插入数据----------------------------
-------------------------------------------------------------- 
INSERT department VALUES
(DEFAULT,'外科','南区二楼101','12345678'),
(DEFAULT,'牙科','南区二楼103','14545678'),
(DEFAULT,'内科','南区一楼102','11223344');
INSERT doctor VALUES
(DEFAULT,101,'张三','主任',50,1),
(DEFAULT,102,'张四','副主任',40,2),
(DEFAULT,103,'张五','护士',40,3);
INSERT patient VALUES 
(DEFAULT,101,'李四','男',1,1),
(DEFAULT,102,'李五','女',2,2),
(DEFAULT,103,'李六','男',3,3);
INSERT ward VALUES
(DEFAULT,101,'北区二楼101',1),
(DEFAULT,102,'北区二楼102',2),
(DEFAULT,103,'北区二楼103',3),
(DEFAULT,104,'北区二楼104',1),
(DEFAULT,105,'北区二楼105',2),
(DEFAULT,106,'北区二楼106',3),
(DEFAULT,107,'北区二楼107',1);
--------------------------------------------------------------
------------------------(3)备份数据----------------------------
-------------------------------------------------------------- 
mysqldump -uroot -p --master-data=2 --single-transaction exam>D:/exma.sql
--------------------------------------------------------------
------------------------(4)创建视图----------------------------
-------------------------------------------------------------- 

CREATE VIEW information AS
SELECT dep_name,dep_addr,dep_phone,wad_idc,wad_addr
FROM department AS dep
INNER JOIN ward AS ward 
ON dep.dep_id =ward.dep_id;