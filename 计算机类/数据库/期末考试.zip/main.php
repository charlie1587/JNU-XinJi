<?php
$link = mysqli_connect('127.0.0.1', 'root', 'root');
if (mysqli_connect_error() != null) {
	die(mysqli_connect_error());
}
mysqli_select_db($link, 'exam');
mysqli_set_charset($link, 'utf8');
$sql = "SELECT dep_name,dep_addr,dep_phone,wad_idc,wad_addr
FROM department AS dep
INNER JOIN ward AS ward 
ON dep.dep_id =ward.dep_id LIMIT 5;";
$result = mysqli_query($link, $sql);
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
	$data[] = $row;
}
mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>信息系统</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section>
        <div class="color"></div>
        <div class="color"></div>
        <div class="color"></div>
        <div class="box">
            <h1 align="center">信息系统</h1>
            <br>
            <br>
            <div class="container2">    
                <table border="1" align="center">
				<tr>
					<td align="center">科室名称</td>
					<td align="center">科室地址</td>
					<td align="center">科室电话</td>
					<td align="center">病房号</td>
					<td align="center">病房地址</td>
				</tr>
				<?php if (!empty($data)) : ?>
					<?php foreach ($data as $row) : ?>
						<tr>
							<td><?php echo $row['dep_name']; ?></td>
						
							<td><?php echo $row['dep_addr']; ?></td>
						
							<td><?php echo $row['dep_phone']; ?></td>
						
							<td><?php echo $row['wad_idc']; ?></td>
						
							<td><?php echo $row['wad_addr']; ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</table>
                
            </div>

        </div>
    </section>
</body>

</html>