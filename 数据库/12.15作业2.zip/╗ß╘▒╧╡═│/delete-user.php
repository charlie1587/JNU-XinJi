<?php
    if(!empty($_GET)){
        $emp_no=intval(htmlentities($_GET['id']));
        //连接
        $link = mysqli_connect('127.0.0.1', 'root', 'root');
        if (mysqli_connect_error() != null) {
            die(mysqli_connect_error());
        }
        mysqli_select_db($link, 'employees');
        mysqli_set_charset($link, 'utf8');
        $sql = "DELETE FROM employees WHERE emp_no=$emp_no";
        $result = mysqli_query($link, $sql);
        if($result) {
            echo "<script>alert('删除成功');
                    window.location.href='main.php'
            </script>";
        }else{
            echo "<script>alert('删除失败');
            </script>";
        }
        mysqli_close($link);
    }
?>