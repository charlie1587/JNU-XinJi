<?php
$link = mysqli_connect('127.0.0.1', 'root', 'root');
if (mysqli_connect_error() != null) {
	die(mysqli_connect_error());
}
mysqli_select_db($link, 'employees');
mysqli_set_charset($link, 'utf8');
$sql = "SELECT * FROM employees LIMIT 20";
$result = mysqli_query($link, $sql);
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
	$data[] = $row;
}
mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>会员信息系统</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section>
        <div class="color"></div>
        <div class="color"></div>
        <div class="color"></div>
        <div class="box">
            <h1 align="center">会员信息系统</h1>
            <br>
			<div class="box3" align="center">
				<a href="add-user.php">添加用户</a>
				<a href="search-user.php">搜索用户</a>
			</div>
            <br>
            <div class="container2">    
                <table border="1" align="center">
				<tr>
					<td align="center">id</td>
					<td align="center">birth date</td>
					<td align="center">first name</td>
					<td align="center">last name</td>
					<td align="center">gender</td>
					<td align="center">hire date</td>
					<td align="center">operation</td>
				</tr>
				<?php if (!empty($data)) : ?>
					<?php foreach ($data as $row) : ?>
						<tr>
							<td><?php echo $row['emp_no']; ?></td>
							<td><?php echo $row['birth_date']; ?></td>
							<td align="center"><?php echo $row['first_name']; ?></td>
							<td align="center"><?php echo $row['last_name']; ?></td>
							<td align="center"><?php echo $row['gender']; ?></td>
							<td><?php echo $row['hire_date']; ?></td>
							<td>
								<a href="change-user.php?id=<?=$row['emp_no']?>">修改</a> 
								<a href="delete-user.php?id=<?=$row['emp_no']?>">删除</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</table>
                
            </div>

        </div>
    </section>
</body>

</html>