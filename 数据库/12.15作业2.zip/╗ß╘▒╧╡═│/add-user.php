<?php
    if(!empty($_POST)){
        $emp_no=intval(htmlentities($_POST['emp_no']));
        $birth_date=htmlentities($_POST['birth_date']);
        $first_name=htmlentities($_POST['first_name']);
        $last_name=htmlentities($_POST['last_name']);
        $gender=htmlentities($_POST['gender']);
        $hire_date=htmlentities($_POST['hire_date']);
        //连接
        $link = mysqli_connect('127.0.0.1', 'root', 'root');
        if (mysqli_connect_error() != null) {
            die(mysqli_connect_error());
        }
        mysqli_select_db($link, 'employees');
        mysqli_set_charset($link, 'utf8');
        $sql = "INSERT INTO employees(
            emp_no,birth_date,first_name,last_name,gender,hire_date
        )VALUES(
            $emp_no,'$birth_date','$first_name','$last_name','$gender','$hire_date'
            )";
        $result = mysqli_query($link, $sql);
        if($result) {
            echo "<script>alert('添加成功');
                    window.location.href='main.php'
            </script>";
        }else{
            echo "<script>alert('添加失败');
            </script>";
        }
        mysqli_close($link);
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <section>
    <div class="color"></div>
    <div class="color"></div>
    <div class="color"></div>
    <div class="box">
      <div class="square" style="--i:0;"></div>
      <div class="square" style="--i:1;"></div>
      <div class="square" style="--i:2;"></div>
      <div class="square" style="--i:3;"></div>
      <div class="square" style="--i:4;"></div>
      <div class="container">
        <div class="form">
          <h2>添加用户</h2>
          <form action="add-user.php" method="post">
            <div class="inputBox">
              <input type="text" name='emp_no' placeholder="序号">
            </div>
            <div class="inputBox">
              <input type="text" name='birth_date' placeholder="出生日期">
            </div>
            <div class="inputBox">
              <input type="text" name='first_name' placeholder="名">
            </div>
            <div class="inputBox">
              <input type="text" name='last_name' placeholder="姓">
            </div>
            <div class="inputBox">
              <input type="text" name='gender' placeholder="性别"> 
            </div>
            <div class="inputBox">
              <input type="text" name='hire_date' placeholder="加入时间">
            </div>
            <div class="inputBox" align="center">
              <input type="submit" value="添加用户">
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</body>

</html>