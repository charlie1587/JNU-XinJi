<?php
$link = mysqli_connect('127.0.0.1', 'root', 'root');
if (mysqli_connect_error() != null) {
	die(mysqli_connect_error());
}
mysqli_select_db($link, 'employees');
mysqli_set_charset($link, 'utf8');
if(!empty($_POST)){
    $birth_date=htmlentities($_POST['birth_date']);       // 1
    $first_name=htmlentities($_POST['first_name']);       // 2
    $last_name=htmlentities($_POST['last_name']);         // 3
    $gender=htmlentities($_POST['gender']);               // 4
    $hire_date=htmlentities($_POST['hire_date']);         // 5
    $sql = "SELECT * FROM employees WHERE";
    if(empty($birth_date)&&empty($first_name)&&empty($last_name)&&empty($gender)){
        echo "<script>alert('查询失败');
        window.location.href='search-user.php'
        </script>";
    }
    //找到开始的查询
    $count=1;
    if(empty($birth_date)){
        $count=2;
        if(empty($first_name)){
            $count=3;
            if(empty($last_name)){
                $count=4;
                if(empty($gender)){$count=5;}
            }
        }
    }

    if(!empty($birth_date)){
        $sql="{$sql} birth_date LIKE '%$birth_date%'";
    }
    if(!empty($first_name)){
        if($count==2)$sql="{$sql} first_name LIKE '%$first_name%'";
        else $sql="{$sql} AND first_name LIKE '%$first_name%'";
    }
    if(!empty($last_name)){
        if($count==3)$sql="{$sql} last_name LIKE '%$last_name%'";
        else $sql="{$sql} AND first_name LIKE '%$last_name%'";
    }
    if(!empty($gender)){
        if($count==4)$sql="{$sql} gender LIKE '%$gender%'";
        else $sql="{$sql} AND gender LIKE '%$gender%'";
    }
    if(!empty($hire_date)){
        if($count==5)$sql="{$sql} hire_dare LIKE '%$hire_date%'";
        else $sql="{$sql} AND hire_date LIKE '%$hire_date%'";
    }
    $sql="{$sql};";
    //echo $sql;
    
}
else{
    $sql = "SELECT * FROM employees LIMIT 20";
}
$result = mysqli_query($link, $sql);
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
	$data[] = $row;
}
mysqli_close($link);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>搜索信息</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section>
        <div class="color"></div>
        <div class="color"></div>
        <div class="color"></div>
        <div class="box">
            <h1 align="center">搜索会员</h1>
            <br>
            <div class="inputBox" align="center" >
                <form action="search-user.php" method="POST">
                    <input type="text" name='birth_date' placeholder="出生日期" style="width: 80px;">
                    <input type="text" name='first_name' placeholder="名" style="width: 80px;">
                    <input type="text" name='last_name' placeholder="姓" style="width: 80px;">
                    <input type="text" name='gender' placeholder="性别" style="width: 80px;"> 
                    <input type="text" name='hire_date' placeholder="加入时间" style="width: 80px;">
                    <input type="submit" name='submit' value='查询'>
                </form>
            </div>
            <br>
            <div class="container2">    
                <table border="1" align="center">
				<tr>
					<td align="center">id</td>
					<td align="center">birth date</td>
					<td align="center">first name</td>
					<td align="center">last name</td>
					<td align="center">gender</td>
					<td align="center">hire date</td>
                    <td align="center">operation</td>
				</tr>
				<?php if (!empty($data)) : ?>
					<?php foreach ($data as $row) : ?>
						<tr>
							<td><?php echo $row['emp_no']; ?></td>
							<td><?php echo $row['birth_date']; ?></td>
							<td align="center"><?php echo $row['first_name']; ?></td>
							<td align="center"><?php echo $row['last_name']; ?></td>
							<td align="center"><?php echo $row['gender']; ?></td>
							<td><?php echo $row['hire_date']; ?></td>
                            <td>
								<a href="change-user.php?id=<?=$row['emp_no']?>">修改</a> 
								<a href="delete-user.php?id=<?=$row['emp_no']?>">删除</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</table>
            </div>
            <br>
            <div class="box" align="center">
                <a href="print.php?sql=<?php echo $sql;?>" align="center"> 打印界面</a>
                <a href="main.php" align="center"> 返回</a>
            </div>
            
        </div>
    </section>
</body>

</html>