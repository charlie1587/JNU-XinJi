<?php
    $emp_no=intval(htmlentities($_GET['id']));
    if(empty($emp_no)){
        header('Location:main.php');
    }
    //连接
    $link = mysqli_connect('127.0.0.1', 'root', 'root');
    if (mysqli_connect_error() != null) {
        die(mysqli_connect_error());
    }
    mysqli_select_db($link, 'employees');
    mysqli_set_charset($link, 'utf8');
    $sql = "SELECT birth_date,first_name,last_name,gender,hire_date
        FROM employees WHERE emp_no=$emp_no";
    $result = mysqli_query($link, $sql);
    $current_user=mysqli_fetch_assoc($result);
    if(empty($current_user)){
        header('Location:main.php');
    }
    if(!empty($_POST)){
        $birth_date=htmlentities($_POST['birth_date']);
        $first_name=htmlentities($_POST['first_name']);
        $last_name=htmlentities($_POST['last_name']);
        $gender=htmlentities($_POST['gender']);
        $hire_date=htmlentities($_POST['hire_date']);
        $sql = "UPDATE employees SET 
        birth_date =  '$birth_date',
        first_name = '$first_name',
        last_name = '$last_name',
        gender = '$gender',
        hire_date = '$hire_date'
        where emp_no= $emp_no;";
        $result = mysqli_query($link, $sql);
        if($result) {
            echo "<script>alert('修改成功');
                    window.location.href='change-user.php';
            </script>";
            $current_user=array_merge($current_user, $_POST);
        }else{
            echo "<script>alert('修改失败');
            window.location.href='change-user.php';
            </script>";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <section>
    <div class="color"></div>
    <div class="color"></div>
    <div class="color"></div>
    <div class="box">
      <div class="square" style="--i:0;"></div>
      <div class="square" style="--i:1;"></div>
      <div class="square" style="--i:2;"></div>
      <div class="square" style="--i:3;"></div>
      <div class="square" style="--i:4;"></div>
      <div class="container">
        <div class="form">
            <h2>修改用户<?php echo $emp_no; ?></h2>
            <form action="change-user.php?id=<?=$emp_no?>" method="post">
            <div class="inputBox">
                <input type="text" name='birth_date' placeholder="出生日期" value="<?php echo $current_user['birth_date']; ?>">
            </div>
            <div class="inputBox">
                <input type="text" name='first_name' placeholder="名" value="<?php echo $current_user['first_name'];?>">
            </div>
            <div class="inputBox">
                <input type="text" name='last_name' placeholder="姓" value="<?php echo $current_user['last_name'];?>">
            </div>
            <div class="inputBox">
                <input type="text" name='gender' placeholder="性别" value="<?php echo $current_user['gender'];?>"> 
            </div>
            <div class="inputBox">
                <input type="text" name='hire_date' placeholder="加入时间" value="<?php echo $current_user['hire_date'];?>">
            </div>
            <div class="inputBox" align="center">
                <input type="submit" value="修改用户">
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>
</body>

</html>