<?php
$link = mysqli_connect('127.0.0.1', 'root', 'root');
mysqli_select_db($link, 'employees');
mysqli_set_charset($link, 'utf8');
if(!empty($_GET)){
    $sql=htmlentities($_GET['sql']); 
    //echo $sql;
    $result = mysqli_query($link, $sql);
    $data = [];
    while ($row = mysqli_fetch_assoc($result)) {
	$data[] = $row;
    }
mysqli_close($link);

}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>打印</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <section>
        <div class="color"></div>
        <div class="color"></div>
        <div class="color"></div>
        <div class="box">
        <h1 align="center">检索结果</h1>
                <br>
            <div class="container2">    
                <table border="1" align="center">
				<tr>
					<td align="center">id</td>
					<td align="center">birth date</td>
					<td align="center">first name</td>
					<td align="center">last name</td>
					<td align="center">gender</td>
					<td align="center">hire date</td>
				</tr>
				<?php if (!empty($data)) : ?>
					<?php foreach ($data as $row) : ?>
						<tr>
							<td><?php echo $row['emp_no']; ?></td>
							<td><?php echo $row['birth_date']; ?></td>
							<td align="center"><?php echo $row['first_name']; ?></td>
							<td align="center"><?php echo $row['last_name']; ?></td>
							<td align="center"><?php echo $row['gender']; ?></td>
							<td><?php echo $row['hire_date']; ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</table>
            </div>
            <br>
            <div class="box" align="center">
                <a href="search-user.php" align="center"> 返回</a>
            </div>
            
        </div>
    </section>
</body>

</html>